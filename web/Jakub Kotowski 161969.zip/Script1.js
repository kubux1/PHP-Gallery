// JavaScript source code
function dzialaj() {
    $("#mainDiv").addClass("poem-text").children("p").addClass("poem-line").children("span").
   addClass("poem-comment").toggle("slow");
}